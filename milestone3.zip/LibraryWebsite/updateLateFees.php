<?php

// Updates the late fees for all checked out books for a specific user. This function is used in checkoutBook.php 
// to ensure that the user's late fees are up to date before checking if they have any overdue books or unpaid late fees.
function updateLateFees($conn, $userID) {

    //SQL statement used to update the late fees for all checked out books for the specified user.
    $stmt = $conn->prepare(
        "UPDATE checkouts
         SET late_fee = LEAST(
             25, TIMESTAMPDIFF(DAY, due_date, NOW())
         )
         WHERE user_id = ?
         AND status = 'checked_out'
         AND return_date IS NULL
         AND due_date < NOW()"
    );

    $stmt->bind_param("i", $userID);
    $stmt->execute();
    $stmt->close();
}